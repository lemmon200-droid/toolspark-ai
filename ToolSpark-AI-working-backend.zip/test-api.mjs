// Run with: node test-api.mjs
const r = await fetch("http://localhost:3000/api/health");
console.log(await r.json());
