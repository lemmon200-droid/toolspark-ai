import "dotenv/config";
import express from "express";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
const port = Number(process.env.PORT || 3000);
const model = process.env.OPENAI_MODEL || "gpt-6-luna";
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.disable("x-powered-by");
app.use(express.json({ limit: "64kb" }));
app.use(express.static(path.join(__dirname, "public")));

const TOOL_PROMPTS = {
  email: `Write a polished email based on the user's request. Return only the email body, with a useful subject line at the top. Do not invent personal details.`,
  resume: `Improve the user's resume text for clarity, impact, grammar, and ATS-friendly wording. Preserve factual claims and do not invent jobs, degrees, dates, skills, or achievements. Return the improved resume text.`,
  caption: `Create 5 engaging social-media caption options based on the user's idea. Keep them concise and distinct. Do not invent specific facts.`,
  rewrite: `Rewrite the user's text so it is clearer and more polished while preserving its meaning. Return only the rewritten text.`,
  summarize: `Summarize the user's text clearly and accurately. Preserve important facts and avoid adding information. Use concise bullets when useful.`,
  ideas: `Generate 10 practical ideas based on the user's topic. Make them specific and useful. Do not claim that uncertain facts are true.`
};

const buckets = new Map();
const WINDOW_MS = 60_000;
const MAX_REQUESTS = Number(process.env.RATE_LIMIT_PER_MINUTE || 10);

function rateLimit(req, res, next) {
  const key = req.ip || "unknown";
  const now = Date.now();
  const bucket = buckets.get(key) || { start: now, count: 0 };

  if (now - bucket.start >= WINDOW_MS) {
    bucket.start = now;
    bucket.count = 0;
  }

  bucket.count += 1;
  buckets.set(key, bucket);

  if (bucket.count > MAX_REQUESTS) {
    return res.status(429).json({
      error: "Too many requests. Please wait a minute and try again."
    });
  }
  next();
}

// Periodically remove stale rate-limit entries.
setInterval(() => {
  const cutoff = Date.now() - WINDOW_MS * 2;
  for (const [key, bucket] of buckets) {
    if (bucket.start < cutoff) buckets.delete(key);
  }
}, WINDOW_MS * 2).unref();

app.get("/api/health", (_req, res) => {
  res.json({ ok: true });
});

app.post("/api/generate", rateLimit, async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({
        error: "Server is missing OPENAI_API_KEY. Add it to your environment."
      });
    }

    const { tool, text } = req.body ?? {};

    if (!TOOL_PROMPTS[tool]) {
      return res.status(400).json({ error: "Unknown tool." });
    }

    if (typeof text !== "string" || !text.trim()) {
      return res.status(400).json({ error: "Please enter some text first." });
    }

    const cleanText = text.trim();
    const maxChars = Number(process.env.MAX_INPUT_CHARS || 12000);

    if (cleanText.length > maxChars) {
      return res.status(413).json({
        error: `Input is too long. Please keep it under ${maxChars.toLocaleString()} characters.`
      });
    }

    const response = await client.responses.create({
      model,
      instructions: TOOL_PROMPTS[tool],
      input: cleanText
    });

    const output = (response.output_text || "").trim();

    if (!output) {
      return res.status(502).json({
        error: "The AI returned an empty response. Please try again."
      });
    }

    res.json({ result: output });
  } catch (error) {
    console.error("OpenAI request failed:", error);

    const status = Number(error?.status);
    if (status === 401) {
      return res.status(500).json({ error: "The server's OpenAI API key is invalid." });
    }
    if (status === 429) {
      return res.status(503).json({
        error: "AI service rate limit reached. Please try again shortly."
      });
    }

    res.status(500).json({
      error: "Something went wrong while generating the result. Please try again."
    });
  }
});

app.get("*", (req, res) => {
  if (req.path.startsWith("/api/")) {
    return res.status(404).json({ error: "API route not found." });
  }
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(port, () => {
  console.log(`ToolSpark AI running on http://localhost:${port}`);
});
