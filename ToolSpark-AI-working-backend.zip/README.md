# ToolSpark AI — Working Backend

This version connects the ToolSpark AI frontend to an OpenAI backend using the Responses API.

## What is included

- Node.js + Express server
- OpenAI Responses API integration
- Server-side API key (never exposed to browser code)
- Six working tools:
  - AI Email Writer
  - Resume Improver
  - Social Caption Maker
  - Text Rewriter
  - AI Summarizer
  - Idea Generator
- Input validation and length limits
- Basic per-IP rate limiting
- Health endpoint at `/api/health`
- `.env.example` for configuration

## Run it locally

1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Install dependencies:

   `npm install`

4. Create your environment file:

   `cp .env.example .env`

   On Windows PowerShell:

   `Copy-Item .env.example .env`

5. Put your OpenAI API key in `.env`:

   `OPENAI_API_KEY=...`

6. Start the server:

   `npm start`

7. Open:

   `http://localhost:3000`

## Important security rule

Never put `OPENAI_API_KEY` inside `public/index.html` or browser JavaScript. The browser calls `/api/generate`; only the server talks to OpenAI.

## Production notes

- Set `OPENAI_API_KEY` as a secret/environment variable in your hosting provider.
- Do not commit `.env` to Git.
- The included rate limiter is intentionally simple and in-memory. For a larger public site, use a shared store such as Redis and add authentication/quotas.
- Add a real privacy policy and terms before collecting user content at scale.
- API usage is billable according to the selected model. Set a spending limit/budget and keep the site's free usage quota below your expected revenue.

## API

POST `/api/generate`

Example JSON:

`{"tool":"email","text":"Write an email asking a client to reschedule our meeting."}`

Response:

`{"result":"..."}`

GET `/api/health`

Returns:

`{"ok":true}`
